from rest_framework import serializers

from .models import Notification


class NotificationSerializer(serializers.ModelSerializer):

    class Meta:
        model = Notification
        fields = [
            "id",
            "recipient",
            "title",
            "message",
            "notification_type",
            "related_object_id",
            "is_read",
            "created_at",
            "read_at",
        ]
        read_only_fields = fields


class MarkAllReadResponseSerializer(serializers.Serializer):
    """Response shape for the mark-all-read action."""

    marked_read = serializers.IntegerField()