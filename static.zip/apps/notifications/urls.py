from rest_framework.routers import DefaultRouter

from .views import NotificationViewSet

app_name = "notifications_api"

router = DefaultRouter()
router.register(r"notifications", NotificationViewSet, basename="notification")

urlpatterns = router.urls